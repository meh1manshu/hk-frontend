import Link from "next/link";

export default function Home() {
  return (
    <main style={{height:"100vh",display:"flex",flexDirection:"column",justifyContent:"center",alignItems:"center"}}>
      <h1 style={{fontSize:"64px"}}>CRAFTED FOR YOU</h1>
      <p style={{opacity:0.7}}>Luxury custom-built T‑shirts</p>
      <Link href="/customize">
        <button style={{marginTop:"30px",padding:"15px 40px",fontSize:"16px"}}>CREATE YOUR T‑SHIRT</button>
      </Link>
    </main>
  );
}
