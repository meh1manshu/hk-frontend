export default function Customize() {
  return (
    <div style={{padding:"40px"}}>
      <h1>Design Your T‑Shirt</h1>
      <p>Configurator UI will appear here.</p>
    </div>
  );
}
